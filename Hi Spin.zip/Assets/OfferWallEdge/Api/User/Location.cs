namespace FyberPlugin
{
    public class Location
	{
		public double Long { get; set; }
		public double Lat { get; set; }

	}
}

