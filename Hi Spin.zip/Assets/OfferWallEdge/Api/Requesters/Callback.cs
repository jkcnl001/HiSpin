namespace FyberPlugin
{
	public interface Callback
	{
		void OnRequestError(RequestError error);
	}
}

