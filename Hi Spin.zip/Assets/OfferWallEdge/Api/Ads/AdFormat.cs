namespace FyberPlugin
{
    public enum AdFormat
    {

        /**
         * Offer Wall ad format.
         */
        OFFER_WALL = 0,
        /**
         * Unknown ad format.
         */
        UNKNOWN
    }
}