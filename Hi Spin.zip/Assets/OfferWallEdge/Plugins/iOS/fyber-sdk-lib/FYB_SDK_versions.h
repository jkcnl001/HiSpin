//
//
// Copyright (c) 2017 Fyber. All rights reserved.
//
//

static const NSInteger FYBSDKReleaseVersionNumberMajor = 9;
static const NSInteger FYBSDKReleaseVersionNumberMinor = 2;
static const NSInteger FYBSDKReleaseVersionNumberPatch = 0;
