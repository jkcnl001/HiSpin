//
//
// Copyright (c) 2017 Fyber. All rights reserved.
//
//

#import "FYBLogAppender.h"

@interface FYBSystemLogger : NSObject<FYBLogAppender>

@end
