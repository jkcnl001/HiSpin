//
//
// Copyright (c) 2017 Fyber. All rights reserved.
//
//

@import Foundation;
#import "FYBIdValidator.h"

FOUNDATION_EXPORT NSString *const FYBExceptionInvalidActionId;

@interface FYBActionIdValidator : NSObject <FYBIdValidator>

@end
