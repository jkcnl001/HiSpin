package com.Gradle;

public class AndroidUtil
{
	public static int GetAndroidVersion()
	{
		return android.os.Build.VERSION.SDK_INT;
	}
}