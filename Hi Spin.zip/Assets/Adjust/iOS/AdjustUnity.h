//
//  AdjustUnity.h
//  Adjust SDK
//
//  Created by Pedro Silva (@nonelse) on 27th March 2014.
//  Copyright © 2012-2018 Adjust GmbH. All rights reserved.
//

/**
 * @brief The main interface to Adjust Unity bridge.
 */
@interface AdjustUnity : NSObject

@end
